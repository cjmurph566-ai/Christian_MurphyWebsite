import java.util.Scanner;

public class cmwebsite {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice = -1;

        while (choice != 7) {
            System.out.println("\n============================================");
            System.out.println(" Welcome to Christian Murphy's Personal Site ");
            System.out.println("============================================");
            System.out.println("Location: Norfolk, VA");
            System.out.println("--------------------------------------------");
            System.out.println("1. Home");
            System.out.println("2. About");
            System.out.println("3. Resume");
            System.out.println("4. Projects");
            System.out.println("5. Organizations");
            System.out.println("6. Contact");
            System.out.println("7. Exit");
            System.out.print("\nEnter your choice: ");

            // get user input
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // consume newline
            } else {
                System.out.println("Please enter a valid number!");
                scanner.nextLine();
                continue;
            }

            System.out.println();

            switch (choice) {
                case 1:
                    showHome();
                    break;
                case 2:
                    showAbout();
                    break;
                case 3:
                    showResume();
                    break;
                case 4:
                    showProjects();
                    break;
                case 5:
                    showOrganizations();
                    break;
                case 6:
                    showContact();
                    break;
                case 7:
                    System.out.println("Thank you for visiting Christian Murphy’s personal site. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    private static void showHome() {
        System.out.println("🏠 HOME");
        System.out.println("--------------------------------------------");
        System.out.println("Welcome to my personal website! My name is Christian Murphy,");
        System.out.println("a Computer Science student from Norfolk, VA with a passion for");
        System.out.println("cybersecurity, data analytics, and AI development.");
    }

    private static void showAbout() {
        System.out.println("🏠 ABOUT");
        System.out.println("--------------------------------------------");
        System.out.println("This is my personal website where you can learn more about me,");
        System.out.println("my projects, and my academic journey. I enjoy exploring how");
        System.out.println("technology can solve real-world problems through coding,");
        System.out.println("data, and innovation.");
    }

    private static void showResume() {
        System.out.println("🏠 RESUME");
        System.out.println("--------------------------------------------");
        System.out.println("Education:");
        System.out.println("• Virginia State University — B.S. in Computer Science (Expected May 2028)");
        System.out.println("• Elizabeth City State University — B.S. in Computer Science (Aug 2024 – May 2025)");
        System.out.println();
        System.out.println("Certifications:");
        System.out.println("• IBM Artificial Intelligence Fundamentals (2025)");
        System.out.println();
        System.out.println("Skills:");
        System.out.println("• Java, Python, JavaScript");
        System.out.println("• Cybersecurity fundamentals & penetration testing");
        System.out.println("• SQL, Data analytics, AI/ML concepts");
        System.out.println("• Git, Linux, and problem-solving");
    }

    private static void showProjects() {
        System.out.println("🏠 PROJECTS");
        System.out.println("--------------------------------------------");
        System.out.println("1. Kinetic Energy Program — Created a JavaScript tool that calculates");
        System.out.println("   the kinetic energy of an object based on mass and velocity inputs.");
        System.out.println();
        System.out.println("2. Target Heart Rate Program — Designed a Java-based calculator that");
        System.out.println("   determines optimal heart rate zones for personal fitness goals.");
        System.out.println();
        System.out.println("3. Penetration Testing Project — Conducted ethical hacking simulations");
        System.out.println("   to assess and strengthen system security.");
    }

    private static void showOrganizations() {
        System.out.println("🏠 ORGANIZATIONS");
        System.out.println("--------------------------------------------");
        System.out.println("• NSBE (National Society of Black Engineers) — Member");
        System.out.println("• Trojan Tech Defenders — Cybersecurity Club Member");
        System.out.println("• Coding Club — Peer Collaboration and Learning");
        System.out.println("• Crown Him Program — Volunteer Leader");
        System.out.println("• NCAA Football — Student-Athlete Participant");
    }

    private static void showContact() {
        System.out.println("🏠 CONTACT");
        System.out.println("--------------------------------------------");
        System.out.println("You can reach me by email at:");
        System.out.println("   cjmurph566@gmail.com");
        System.out.println();
        System.out.println("Thank you for visiting my Java personal site!");
    }
}
